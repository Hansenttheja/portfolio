<?php

$host= "localhost";
$user = "root";
$pass = "";
$db	="tugas1";

$con = mysqli_connect($host,$user,$pass,$db);
?>