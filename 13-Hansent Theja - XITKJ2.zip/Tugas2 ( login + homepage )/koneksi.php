<?php

$host= "localhost";
$user = "root";
$pass = "";
$db	="tugas2";

$con = mysqli_connect($host,$user,$pass,$db);
?>